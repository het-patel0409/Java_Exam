/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servletDemo;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author iampo
 */
public class RadiobuttonDemo2 extends HttpServlet {
 @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String operation = request.getParameter("operation");
        
        int num1 = Integer.parseInt(request.getParameter("num1"));
        int num2 = Integer.parseInt(request.getParameter("num2"));
        
        int result = 0;
        
        switch (operation) 
        {
         case "add":
             result = num1 + num2;
             break;
         case "sub":
             result = num1 - num2;
             break;
         case "mult":
             result = num1 * num2;
             break;
         case "div":
             result = num1 / num2;
             break;
         default:
             break;
        }
        
        out.println("<html>");
        out.println("<body bgcolor='blue'>");
        out.println("<h2>Result: " + result + "</h2>");
        out.println("</html>");
        out.println("</body>");
    }
}
