/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package attributes;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * Set and Get attribute Servlet
 * 
 * @author iampo
 */
public class GetAttributeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        //GET application scoped attribute
        String applicationScope = (String)request.getServletContext().getAttribute("name");
        //GET session scoped attribute
        HttpSession session = request.getSession();
        String sessionScope = (String)session.getAttribute("name");
        //GET request scoped attribute
        String requestScope = (String)request.getAttribute("name");
        //print response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        out.println("<h2>Servlet Attribute Examples:- <br>Application Scope, Session Scope and Request scope</h2>");
        out.println("<p>Application Scope : " + applicationScope + "</p>");
        out.println("<p>Session Scope : " + sessionScope + "</p>");
        out.println("<p>Request Scope : " + requestScope + "</p>");
        out.println("</body>");
        out.println("</html>");
        if(session != null){
           session.removeAttribute("name");
        }
        }
}
