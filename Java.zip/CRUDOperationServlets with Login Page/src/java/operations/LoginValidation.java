/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package operations;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author iampo
 */
public class LoginValidation extends HttpServlet {

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String uname1 = request.getParameter("uname");
        String pass1 = request.getParameter("pass");
        Connection con = null;
        try {
            //Loading driver 
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            //Building query
            String query = "SELECT * FROM student WHERE username = '" + uname1 + "' AND password = '" + pass1 + "'";
            //Firing query to database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            if (rs.next()) 
            {
                String user = rs.getString("username");
                String password = rs.getString("password");
                out.println(user);
                out.println(password);
                out.println("<html>");
                out.println("<body bgcolor='orange'><br><br>");

                if (user.equals(uname1) && password.equals(pass1)) 
                {
                    response.sendRedirect("List");
                } 
                else 
                {
                    out.println("<b> Sorry,  Your UserName or Password is Incorrect!!!");
                    response.sendRedirect("LoginPage");
                }
            } 
                else 
                {
                    out.println("<b> Sorry,  Your UserName or Password is Incorrect!!!");
                    response.sendRedirect("LoginPage");
                }


            rs.close();
            stmt.close();
            con.close();
            } catch (Exception e) {
                System.out.println(e);
            }
            out.println("</body>");
            out.println("</html>");
    }
}