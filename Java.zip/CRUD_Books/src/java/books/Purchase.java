package books;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Purchase extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String bname = request.getParameter("bname");
        String bprice = request.getParameter("bprice");
        String bookIdStr = request.getParameter("bookId");

        out.println("<html>");
        out.println("<body bgcolor='cyan'>");
        out.println("<center><h1>Purchase a Book</h1></center>");
        out.println("<table border='1' align='center'>");
        out.println("<tr><th>Book Name</th><th>Book Price</th></tr>");
        out.println("<tr><td>" + bname + "</td><td>" + bprice + "</td></tr>");
        out.println("</table>");

        if (bookIdStr != null && !bookIdStr.isEmpty()) {
            out.println("<form action='Quantity' method='post'>");
            out.println("<input type='hidden' name='bname' value='" + bname + "'>");
            out.println("<input type='hidden' name='bprice' value='" + bprice + "'>");
            out.println("<input type='hidden' name='bookId' value='" + bookIdStr + "'>");
            out.println("<table border='1' align='center'>");
            out.println("<tr><td>Book Quantity:</td><td><input type='number' name='quantity' required></td></tr>");
            out.println("<tr><th colspan='2'><input type='submit' value='Calculate Total'></th></tr>");
            out.println("</table>");
            out.println("</form>");
        } 
        else 
        {
            out.println("<p>Please go back and select a valid book.</p>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}

