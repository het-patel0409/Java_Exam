package books;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Quantity extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection con;

        double bprice = Double.parseDouble(request.getParameter("bprice"));
        int bookId = Integer.parseInt(request.getParameter("bookId")); // Remove the unnecessary line
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String bname = request.getParameter("bname");

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
            String query = "SELECT bname FROM book WHERE id = ?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setInt(1, bookId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                bname = rs.getString("bname");
                double totalBill = bprice * quantity;

                out.println("<html><body bgcolor= 'green'>");
                out.println("<center><h1>Order Summary</h1></center>");
                out.println("<table border='1' align='center'>");
                out.println("<tr><th>Book Name</th><th>Book Price</th><th>Book Quantity</th><th>Book Total Bill</th></tr>");
                out.println("<tr><td>" + bname + "</td><td>" + bprice + "</td><td>" + quantity + "</td><td>" + totalBill + "</td></tr>");
                out.println("</table>");
                out.println("</body></html>");
            } 
            else 
            {
                // Handle the case where the book with the given ID does not exist
                out.println("<html><body>");
                out.println("<h2>Error</h2>");
                out.println("<p>Book not found</p>");
                out.println("</body></html>");
            }
            rs.close();
            pstmt.close();
            con.close();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
}
