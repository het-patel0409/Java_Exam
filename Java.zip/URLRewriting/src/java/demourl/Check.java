/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package demourl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class Check extends HttpServlet {
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String gender = request.getParameter("gender");
        String uname = request.getParameter("uname");
        String pass = request.getParameter("pass");
        
        out.println("<html>");
        out.println("<body bgcolor='orange'><br><br>");
        
        if(gender.equals("M"))
        {
            response.sendRedirect("Male?user=" + uname + "&pwd=" + pass);
        }
        else
        {
            response.sendRedirect("Female?user=" + uname + "&pwd=" + pass);
        }
        
        out.println("</body>");
        out.println("</html>");
    }
    
}
