/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package config;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * ServletContext using single parameter passing single value
 * 
 * @author iampo
 */
public class MyServlet3 extends HttpServlet {

     @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor ='cyan'>");
        //Creating ServletContext object
        ServletContext context = getServletContext();
        //Getting the value of the initialization paramter and printing it
        String str = context.getInitParameter("Pooja");
        out.println("The value of Param-Name from web.xml :" + str);
        out.println("<body>");
        out.println("<html>");
    }
}
