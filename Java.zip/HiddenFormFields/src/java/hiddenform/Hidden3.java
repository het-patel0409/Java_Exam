/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package hiddenform;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class Hidden3 extends HttpServlet {
@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor='blue'>");
        
        String uname = request.getParameter("uname");
        String pass = request.getParameter("pass");
        
        out.println("<h2>Name: " + uname + "</h2>");
        out.println("<h2>Password: " + pass + "</h2>");
        
        out.println("</body>");
        out.println("</html>");
    }
   
}
