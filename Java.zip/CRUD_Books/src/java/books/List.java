/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package books;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author iampo
 */
public class List extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor= 'cyan'>");

        out.println("<center><h1> Books Table <h1> <Center>");
      
        Connection con = null;
        try {
            //Loading driver 
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            //Building query
            String query = "select * from book";
            //Firing query to database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            out.println("<table border = '1' align='center'>");
            out.println("<tr>");
            out.println("<th> Book Id</th>");
            out.println("<th> Book Name</th>");
            out.println("<th> Book Price</th>");
            out.println("<th> Purchase </th>");
            out.println("</tr>");

             while (rs.next()) 
            {
                String id = rs.getString("id");
                String bprice = rs.getString("bprice");
                out.println("<tr>");
                out.println("<td>" + id + " </td>");
                out.println("<td>" + rs.getString("bname") + "</td>");
                out.println("<td>" + rs.getString("bprice") + "</td>");
                out.println("<td> <a href='Purchase?bookId=" + id + "&bname=" + rs.getString("bname") + "&bprice=" + rs.getString("bprice") + "'>Purchase</a></td>");
            }
            
            out.println("</table>");
            out.println("<br><Center><a href = 'Add'>Add New Book</a></Center><br>");
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        out.println("</body>");
        out.println("</html>");
    }
}
