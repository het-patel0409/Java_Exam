/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * For MyFilter1 create java class not servlet bz its uses implements
 * This MyFilter1 is for OrderServlet.java and ProfileServlet.java
 * html code is commonly written in index.html having 2 hyper link
 * 
 * @author iampo
 */
public class MyFilter1 implements Filter {

    @Override
    public void init(FilterConfig config) 
       throws ServletException {
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
        throws IOException, ServletException {
         
        System.out.println("Filter Before Servlet");
        //.....
        //.....
        fc.doFilter(request, response);
        System.out.println("Filter After Servlet");
        //.....
        //.....
    }
    
    @Override
    public void destroy() {
       
    }
}
