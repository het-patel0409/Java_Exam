/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package operations;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author iampo
 */
public class List extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor= 'cyan'>");

        out.println("<center><h1> CRUD Operation On Student Table<h1> <Center>");
      
        Connection con = null;
        try {
            //Loading driver 
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            //Building query
            String query = "select * from student order  by sno";
            //Firing query to database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            out.println("<table border = '1' align='center'>");
            out.println("<tr>");
            out.println("<th> Student Sno</th>");
            out.println("<th> Student Sname</th>");
            out.println("<th> Student Sage</th>");
            out.println("<th> Student Username</th>");
            out.println("<th> Student Password</th>");
            out.println("<th>Update</th>");
            out.println("<th>Delete</th>");
            out.println("</tr>");

            while (rs.next()) {
                String sno = rs.getString("sno");
                String sage = rs.getString("sage");
                out.println("<tr>");
                out.println("<td>" + sno + " </td>");
                out.println("<td>" + rs.getString("sname") + "</td>");
                out.println("<td>" + rs.getString("sage") + "</td>");
                out.println("<td>" + rs.getString("username") + "</td>");
                out.println("<td>" + rs.getString("password") + "</td>");
                out.println("<td> <a href = 'Update?sno=" + sno + "'>Update</a></td>");
                out.println("<td> <a href = 'Delete?sno=" + sno + "' > Delete </a> </td>");
            }
            
            out.println("</table>");
            out.println("<br><Center><a href = 'Add'>Add New Student</a></Center><br>");
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        out.println("</body>");
        out.println("</html>");
    }
}
