/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package sessions;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class Session2 extends HttpServlet {
@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor='cyan'>");
        
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        
        HttpSession session = request.getSession();
        session.setAttribute("uid", name);
        session.setAttribute("pwd", password);
        
        out.println("<Form action='Session3'>");
        out.println("<Input type='submit' value='Submit'><br><br>");
        
        out.println("</from>"); 
        out.println("</body>");
        out.println("</html>");
    }
}
