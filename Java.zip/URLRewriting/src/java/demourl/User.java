/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package demourl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class User extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Form</title>");
        out.println("</head>");
        out.println("<body bgcolor='cyan'>");
        out.println("<form action='Check'>");
        
        out.println("Name:<input type='text' name='uname'><br><br>");
        out.println("Password:<input type='password' name='pass'><br><br>");
        
        out.println("Gender:<br><input type='radio' name='gender' value='M'> Male<br>");
        out.println("<input type='radio' name='gender' value='F'> Female<br>");
        
        out.println("<input type='submit' value='Submit'>");
        
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }
}
